function uploadFile() {
    const fileInput = document.getElementById("file");
    const statusText = document.getElementById("status");

    if (fileInput.files.length === 0) {
        statusText.textContent = "يرجى اختيار ملف للرفع.";
        return;
    }

    const formData = new FormData();
    formData.append("file", fileInput.files[0]);

    statusText.textContent = "جاري رفع الملف...";

    // إرسال الملف إلى File.io
    fetch("https://file.io/?expires=1d", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            statusText.innerHTML = `تم رفع الملف بنجاح! <a href="${data.link}" target="_blank">رابط الملف</a>`;
        } else {
            statusText.textContent = "حدث خطأ أثناء رفع الملف.";
        }
    })
    .catch(() => {
        statusText.textContent = "فشل الاتصال بخادم الرفع.";
    });
}
